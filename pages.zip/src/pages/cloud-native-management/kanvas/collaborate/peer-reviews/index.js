import React from "react";
import Comments from "../../../../../sections/Comments";

const CommentsPage = () => {
  return (
    <Comments/>
  );
};

export default CommentsPage;