import React from "react";
import SistentComponents from "../../../../sections/Projects/Sistent/components";

const SistentComponentsPage = () => {
  return <SistentComponents />;
};

export default SistentComponentsPage;
