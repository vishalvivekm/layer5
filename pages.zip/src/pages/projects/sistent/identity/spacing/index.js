import React from "react";
import SistentIdentitySpacing from "../../../../../sections/Projects/Sistent/identity/spacing/index";

const IdentitySpacingPage = () => {
  return <SistentIdentitySpacing />;
};

export default IdentitySpacingPage;
