import React from "react";
import { SpacingCode } from "../../../../../sections/Projects/Sistent/identity/spacing/code";

const SpacingCodePage = () => {
  return <SpacingCode />;
};

export default SpacingCodePage;
