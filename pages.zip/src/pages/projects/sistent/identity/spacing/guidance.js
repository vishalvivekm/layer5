import React from "react";
import { SpacingGuidance } from "../../../../../sections/Projects/Sistent/identity/spacing/guidance";

const SpacingGuidancePage = () => {
  return <SpacingGuidance />;
};

export default SpacingGuidancePage;
