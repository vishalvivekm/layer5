import React from "react";
import ColorCode from "../../../../../sections/Projects/Sistent/identity/color/code";

const ColorCodePage = () => {
  return <ColorCode />;
};

export default ColorCodePage;
