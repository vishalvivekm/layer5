import React from "react";
import ColorGuidance from "../../../../../sections/Projects/Sistent/identity/color/guidance";

const ColorGuidancePage = () => {
  return <ColorGuidance />;
};

export default ColorGuidancePage;
