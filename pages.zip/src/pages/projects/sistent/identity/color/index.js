import React from "react";
import SistentIdentityColor from "../../../../../sections/Projects/Sistent/identity/color";

const SistentIdentityColorPage = () => {
  return <SistentIdentityColor />;
};

export default SistentIdentityColorPage;
