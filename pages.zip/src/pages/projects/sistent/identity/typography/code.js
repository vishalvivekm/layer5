import React from "react";
import TypographyCode from "../../../../../sections/Projects/Sistent/identity/typography/code";

const TypographyCodePage = () => {
  return <TypographyCode />;
};

export default TypographyCodePage;
