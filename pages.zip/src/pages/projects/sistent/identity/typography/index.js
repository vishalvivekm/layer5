import React from "react";
import SistentTypography from "../../../../../sections/Projects/Sistent/identity/typography";

const SistentTypographyPage = () => {
  return <SistentTypography />;
};

export default SistentTypographyPage;
