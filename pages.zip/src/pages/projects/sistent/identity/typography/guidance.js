import React from "react";
import TypographyGuidance from "../../../../../sections/Projects/Sistent/identity/typography/guidance";

const TypographyGuidancePage = () => {
  return <TypographyGuidance />;
};

export default TypographyGuidancePage;
