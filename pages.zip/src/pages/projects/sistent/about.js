import React from "react";
import SistentAbout from "../../../sections/Projects/Sistent/about";

const SistentAboutPage = () => {
  return <SistentAbout />;
};

export default SistentAboutPage;
