import React from "react";
import styled from "styled-components";
// import Wasm from "../../assets/images/webassembly/webssembly_icon.svg";
import { Container, Row, Col } from "../../../reusecore/Layout";
import { useStyledDarkMode } from "../../../theme/app/useStyledDarkMode";
import IntegrationDesigner from "./images/layer5-kanvas-designer.webp";
import CatalogImage from "./images/catalog_mac.png";
import DashboardImg from "./images/cncf_hub_dashboard_mac.png";
import PictureSlider from "./picture-slider";
const CatalogWrapper = styled.div`
  min-height: fit-content;
  border-width: 2px 2px 2px 2px;
  background-color: ${(props) => props.theme.body};
  transition: 0.8s cubic-bezier(0.2, 0.8, 0.2, 1);
  padding-top: 100px;
  padding-bottom: 100px;
  @media (max-width: 468px) {
    margin: 3rem 0;
  }
  @media (max-width: 767px) {
    padding-top: 0;
    padding-bottom: 0;
  }
  .catalog-container .catalog:nth-child(odd) {
    .catalog-image {
      .image-wrapper {
        justify-content: center;
        @media (max-width: 767px) {
          justify-content: center;
        }
      }
    }
  }

  .catalog-container .catalog:nth-child(even) {
    .catalog-image {
      @media (max-width: 767px) {
        order: 0;
      }
    }
    .catalog-detail {
      @media (max-width: 767px) {
        order: 1;
      }
    }
  }

  .catalog {
    display: flex;
    padding: 5rem 0;
    @media (max-width: 768px) {
      padding: 2rem 0;
    }
    @media (max-width: 468px) {
      flex-direction: column;
    }
    .catalog-detail {
    .recognition-content {
      display: grid;
      grid-template-columns: minmax(18.75rem, 40%) 1fr;
      min-height: 31.25rem;
      position: relative;
      gap: 2rem;
      .badges-section {
        position: relative;
        display: flex;
        align-items: center;
        justify-content: center;
        .badge-stack {
          position: relative;
          width: 100%;
          height: 100%;
          max-width: 25rem;
          .badge-item {
            position: absolute;
            width: 11.25rem;
            height: 11.25rem;
            transition: 0.8s cubic-bezier(0.2, 0.8, 0.2, 1);
            img {
              width: 140%;
              height: 140%;
              object-fit: contain;
              filter: drop-shadow(0 0.25rem 0.5rem rgba(0, 0, 0, 0.2));
            }
            &:nth-child(1) {
              top: 0;
              left: 0;
              z-index: 3;
            }
            &:nth-child(2) {
              top: 5.625rem;
              left: 5.625rem;
              z-index: 2;
            }
            &:nth-child(3) {
              top: 11.25rem;
              left: 11.25rem;
              z-index: 1;
            }
          }
        }
      }
      display: flex;
      flex-direction: column;
      justify-content: center;
      .heading {
        font-size: 3.125rem;
        line-height: 3.813rem;
        color: ${(props) => props.theme.tertiaryColor};
        transition: 0.8s cubic-bezier(0.2, 0.8, 0.2, 1);
        margin-bottom: 2rem;
        @media (max-width: 992px) {
          font-size: 2.8rem;
          line-height: 3rem;
        }
        @media (max-width: 767px) {
          font-size: 2rem;
          line-height: 2.5rem;
          text-align: center;
          padding-left: 100px;
          padding-right: 100px;
          margin-bottom: 1rem;
        }
        @media (max-width: 467px) {
          padding-left: 25px;
          padding-right: 25px;
        }
      }
      .caption {
        font-weight: 400;
        margin-top: 0;
        padding-left: 15px;
        // font-size: 1.563rem;
        line-height: 2rem;
        color: ${(props) => props.theme.tertiaryColor};
        transition: 0.8s cubic-bezier(0.2, 0.8, 0.2, 1);
        opacity: 0.8;
        li {
          list-style-image: url(https://docs.meshery.io/assets/img/meshery/meshery-logo-light.svg);
        }
        @media (max-width: 767px) {
          font-size: 1rem;
          line-height: 1.5rem;
          // text-align: center;
          padding-left: 100px;
          padding-right: 100px;
        }
        @media (max-width: 467px) {
          padding-left: 25px;
          padding-right: 25px;
        }
      }
    }
    .catalog-image {
      display: flex;
      flex-direction: column;
      justify-content: center;
    .recognition-content {
      display: grid;
      grid-template-columns: minmax(18.75rem, 40%) 1fr;
      min-height: 31.25rem;
      position: relative;
      gap: 2rem;
      .badges-section {
        position: relative;
        display: flex;
        align-items: center;
        justify-content: center;
        .badge-stack {
          position: relative;
          width: 100%;
          height: 100%;
          max-width: 25rem;
          .badge-item {
            position: absolute;
            width: 11.25rem;
            height: 11.25rem;
            transition: 0.8s cubic-bezier(0.2, 0.8, 0.2, 1);
            img {
              width: 140%;
              height: 140%;
              object-fit: contain;
              filter: drop-shadow(0 0.25rem 0.5rem rgba(0, 0, 0, 0.2));
            }
            &:nth-child(1) {
              top: 0;
              left: 0;
              z-index: 3;
            }
            &:nth-child(2) {
              top: 5.625rem;
              left: 5.625rem;
              z-index: 2;
            }
            &:nth-child(3) {
              top: 11.25rem;
              left: 11.25rem;
              z-index: 1;
            }
          }
        }
      }
      .image-wrapper {
        display: flex;
        justify-content: center;
        align-items: center;
        @media (max-width: 767px) {
          justify-content: center;
        }
        .calalog-image {
          max-width: 100%;
          @media (max-width: 767px) {
            max-width: 100%;
            margin-bottom: 20px;
          }
        }
       .badges-section {
        position: relative;
        display: flex;
        align-items: center;
        justify-content: center;
        .badge-stack {
          position: relative;
          width: 100%;
          height: 100%;
          max-width: 25rem;
          .badge-item {
            position: absolute;
            width: 11.25rem;
            height: 11.25rem;
            transition: 0.8s cubic-bezier(0.2, 0.8, 0.2, 1);
            img {
              width: 140%;
              height: 140%;
              object-fit: contain;
              filter: drop-shadow(0 0.25rem 0.5rem rgba(0, 0, 0, 0.2));
            }
            &:nth-child(1) {
              top: 0;
              left: 0;
              z-index: 3;
            }
            &:nth-child(2) {
              top: 5.625rem;
              left: 5.625rem;
              z-index: 2;
            }
            &:nth-child(3) {
              top: 11.25rem;
              left: 11.25rem;
              z-index: 1;
            }
          }
        }
      }
      }
    }
  }
`;

const DevrelContent = () => {

  const { isDark } = useStyledDarkMode();

  return (
    <CatalogWrapper>
      <Container className="catalog-container">
        <Row className="catalog">
          <Col $md={6} className="catalog-image">
            <div className="image-wrapper">
              <img src={IntegrationDesigner} className="calalog-image" />
            </div>
          </Col>
          <Col $md={6} className="catalog-detail">
            <h2 className="heading">Visual, Collaborative Teaching Environment</h2>
            <ul className="caption">
              <li><b>Live Kubernetes Clusters:</b> Give your audience hands-on experience with a collaborative live Kubernetes environment through Meshery Playground</li>
              <li><b>Demonstrate Complex Concepts:</b> Explain cloud native architectures visually and interactively</li>
              <li><b>Multi-Player Teaching:</b> Conduct live demonstrations and workshops where participants can follow along in real-time</li>
            </ul>
          </Col>
        </Row>
        <Row className="catalog">
          <Col $md={6} className="catalog-detail">
            <h2 className="heading">
            Content Creation and Publishing
            </h2>
            <ul className="caption">
              <li><b>Design Cloud Native Patterns:</b> Create and publish custom cloud native design patterns featuring any CNCF project</li>
              <li><b>Curate Reference Architectures:</b> Showcase your expertise by publishing best practices and verified configurations</li>
              <li><b>Develop Learning Paths:</b>Create structured educational journeys that combine theory with hands-on practice</li>
              <li><b>Design Challenges:</b>Create hands-on labs using Meshery Playground that engage your audience through gamification</li>
            </ul>
          </Col>
          <Col $md={6} className="catalog-image">
            {/* <div className="image-wrapper">
              <img src={CatalogImage} className="calalog-image" />
            </div> */}
            <PictureSlider />
          </Col>
        </Row>
        <Row className="catalog">
          <Col $md={6} className="catalog-image">
            <div className="image-wrapper">
              <img src={DashboardImg} className="calalog-image" />
            </div>
          </Col>
          <Col $md={6} className="catalog-detail">
            <h2 className="heading">Build Your Professional Brand</h2>
            <ul className="caption">
              <li><b>Public User Profile:</b>Showcase your cloud native design patterns, contributions, and expertise</li>
              <li><b>Content Attribution:</b> All your published designs, learning paths, and challenges are linked to your profile</li>
              <li><b>Content Metrics:</b> Track popularity and usage of your published content</li>
            </ul>
          </Col>
        </Row>
        {/* <Row className="catalog">
          <Col md={6} className="catalog-image">
            <div className="image-wrapper">
              <img src={isDark ? EbpfDark : Ebpf} className="calalog-image" />
            </div>
          </Col>
          <Col $md={6} className="catalog-detail">
            <h2 className="heading">
              Maximize Your Performance with eBPF Programs
            </h2>
            <p className="caption">
              Embedded within the data plane, eBPF programs enable
              high-performance, granular control over service requests.
            </p>
          </Col>
        </Row> */}
        <Row className="catalog">
          <Col $md={6} className="catalog-detail">
            <h2 className="heading">
            Recognition Program
            </h2>
            <ul className="caption">
              <li><b>Achievement Badges:</b>Earn badges for milestones achieved within the platform</li>
              <li><b>Leaderboard Visibility:</b> Stand out in the community by ranking on challenge leaderboards</li>
              <li><b>Content Popularity:</b>Gain recognition when your designs become most used and referenced</li>
            </ul>
          </Col>
          <Col $md={6} className="catalog-image">
            <div className="recognition-content">
              {/* <img src={Opa} className="calalog-image" /> */}
              <div className="badges-section">
                <div className="badge-stack">
                  <div className="badge-item">
                    <img
                      src="https://badges.layer5.io/assets/badges/docker-captain/docker-captain.png"
                      alt="Docker Captain Badge"
                    />
                  </div>
                  <div className="badge-item">
                    <img
                      src="https://badges.layer5.io/assets/badges/cncf-ambassador/cncf-ambassador.png"
                      alt="CNCF Ambassador Badge"
                    />
                  </div>
                  <div className="badge-item">
                    <img
                      src="https://badges.layer5.io/assets/badges/meshery/meshery.png"
                      alt="Meshery Badge"
                    />
                  </div>
                </div>
              </div>
            </div>
          </Col>
        </Row>
      </Container>
    </CatalogWrapper>
  );
};

export default DevrelContent;
